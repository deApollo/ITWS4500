Ezra Dowd
2/7/2016
Web Science Systems Dev
Lab 1

I have created a dynamic tweet and hashtag display system using bootstrap and jquery.  
-The system is able to handle displaying an arbitrary number of tweets and hashtags at seperate intervals.
-The systems utilizes bootstrap's colum and list layout to make the page look and feel smooth and responsive.
-The system utilizes jquery animations to make transitions between tweets/hashtags as smooth as possible.
-The system also uses the ability to write dynamic html in order to allow each of the hashtags in the hashtags column
 to actually link to its hashtag page on twitter
-The system uses a regular expression to extract hashtags from the overall json data
-The system should be able to reach the end of the set of tweets gracefully by simply starting over again
-Also you can hover over peoples profile images and it will show their profile description

Feel free to peruse the comments in the code for a more detailed look at how the system functions internally.